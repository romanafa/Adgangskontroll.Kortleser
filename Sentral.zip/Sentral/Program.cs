﻿using System.Security.Cryptography.X509Certificates;

namespace Sentral
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
            bool loop=true;
            while(loop)
            {
                Console.WriteLine("Velg en av instillingne i menyen.");
                Console.WriteLine("1. Legg til bruker");
                Console.WriteLine("2. Rediger bruker");
                Console.WriteLine("3. Kortleser");
                Console.WriteLine("4. Avslutt programmet");
                int meny1_valg;
                try
                {
                    meny1_valg = Convert.ToInt16(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Tast inn et heltall for menyvalg");
                    continue; // Invalid input, return to the menu
                }
                switch(meny1_valg)
                {
                    case 1:
                        // Add a new user
                        NewUser temp1 = new NewUser();
                        Console.WriteLine($"Bruker skapt: {temp1.FirstName} {temp1.LastName}, Epost: {temp1.Email}, kort ID: {temp1.CardId}, kort PIN: {temp1.CardPin}, Gyldig fra {temp1.ValidFrom} til {temp1.ValidTo}");
                        break;
                    case 2:
                        // Edit user
                        Console.WriteLine("1 endre Etternavn: ");
                        Console.WriteLine("2 endre Fornavn: ");
                        Console.WriteLine("3 endre E-post:");
                        Console.WriteLine("4 endre Kort ID:");
                        Console.WriteLine("5 endre Gyldighetsperiode DDMMYY og klokkeslett: ");
                        Console.WriteLine("6 endre Pin: ");
                        break;

                    case 3:
                        // Manage Kortleser
                        Console.WriteLine("Nummer [4 siffer]");
                        Console.WriteLine("Plassering");
                        break;

                    case 4:
                        // Exit the program
                        Console.WriteLine("Avslutter programmet...");
                        loop = false;
                        break;

                    default:
                        // Handle invalid input
                        Console.WriteLine("Ugyldig valg, prøv igjen.");
                        break;
                }

                // Ask if the user wants to return to the main menu or exit
                if (loop) // Only ask if loop hasn't been set to false
                {
                    Console.WriteLine("Vil du gå tilbake til hovedmenyen? Tast 'ja' eller 'nei'");
                    string brukervalg = Console.ReadLine();
                    if (brukervalg.ToLower() == "nei")
                    {
                        loop = false;
                    }
                }
            }

            Console.WriteLine("Programmet er avsluttet.");
        }
    }
        }
    

