﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Sentral
{
    internal class NewUser
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string Email { get; set; }
        public int CardId { get; set; }
        public string CardPin { get; set; } // Changed to string to accommodate non-numeric PINs
        public DateTime Created { get; set; }
        public DateTime ValidFrom { get; set; }
        public DateTime ValidTo { get; set; }
        public bool AlwaysValid { get; set; } // Flag to indicate if the card is always valid

        // Konstruktør
        public NewUser()
        {
            Created = DateTime.Now; // Setter oppretelsesdatoen til dagensdato
            CollectUserData();      // kaller metode for å same bruker data ved initialisering.
        }

        // Metode for å hente bruker data
        public void CollectUserData()
        {
            // Ber om etternavn
            Console.WriteLine("Skriv inn brukerens etternavn:");
            LastName = Console.ReadLine();
            while (!IsValidName(LastName))
            {
                Console.WriteLine("Ugyldig etternavn. Vennligst skriv et gyldig etternavn:");
                LastName = Console.ReadLine();
            }

            // Ber om fornavn
            Console.WriteLine("Vennligst skriv inn fornavn:");
            FirstName = Console.ReadLine();
            while (!IsValidName(FirstName))
            {
                Console.WriteLine("Ugyldig fornavn, vennligst skriv et gyldig fornavn:");
                FirstName = Console.ReadLine();
            }

            // 
            Console.WriteLine("Vennligst skriv inn en gyldig e-post:");
            Email = Console.ReadLine();
            while (!IsValidEmail(Email))
            {
                Console.WriteLine("Ugyldig e-post, vennligst skriv en gyldig e-post:");
                Email = Console.ReadLine();
            }

            Console.WriteLine("Vennligst skriv inn den 4 sifrede kort ID'en:");
            string cardIdInput = Console.ReadLine();
            int tempCardId; 
            while (!int.TryParse(cardIdInput, out tempCardId) || !IsValidNumber(tempCardId))
            {
                Console.WriteLine("Ugyldig kort ID. Vennligst skriv inn et gyldig 4-siffret kort ID:");
                cardIdInput = Console.ReadLine();
            }
            // Når gyldig settes kort Id=midlertidig verdi
            CardId = tempCardId;
            // Prompt for PIN
            Console.WriteLine("Bruker definert 4-siffer PIN eller en tileldig generet en? (Tast 'custom' eller 'random'):");
            string pinChoice = Console.ReadLine().ToLower();
            if (pinChoice == "custom")
            {
                Console.WriteLine("Vennligst skriv en 4-siffret PIN:");
                string pinInput = Console.ReadLine();
                while (!IsValidNumber(int.Parse(pinInput))) // Ensure the PIN is valid
                {
                    Console.WriteLine("Ugyldig PIN. Vennligst skriv en gydlig 4-siffret PIN:");
                    pinInput = Console.ReadLine();
                }
                CardPin = pinInput;
            }
            else if (pinChoice == "random")
            {
                Random random = new Random();
                CardPin = random.Next(1000, 9999).ToString();
                Console.WriteLine($"Generert PIN: {CardPin}");
            }
            else
            {
                Console.WriteLine("Ugyldig valg. Start igjen.");
                return;
            }

            // Prompt for Valid From and Valid To dates (including time)
            Console.WriteLine("Er kortet alltid gyldig? (ja eller nei):");
            string alwaysValidInput = Console.ReadLine().ToLower();
            if (alwaysValidInput == "ja")
            {
                AlwaysValid = true;
                ValidFrom = DateTime.MinValue; // Dette representerer "alltid gyldig"
                ValidTo = DateTime.MaxValue;
            }
            else
            {
                AlwaysValid = false;

                // Spør om gyldig tid og dato
                Console.WriteLine("Skriv en gyldig 'Gyldig fra' dato og tid (format: yyyy-MM-dd HH:mm):");
                string validFromInput = Console.ReadLine();
                DateTime tempValidFrom; 
                while (!DateTime.TryParse(validFromInput, out tempValidFrom))
                {
                    Console.WriteLine("Ugyldig tid/dato format skriv inn en 'gyldig fra' dato i formatet yyyy-MM-dd HH:mm:");
                    validFromInput = Console.ReadLine();
                }
                // Ved gyldig verdi, set midlertidig verdi til ValidFrom
                ValidFrom = tempValidFrom;


                // Prompt for gyldig Dato og tid
                Console.WriteLine("Skriv 'Gyldig til' dato og tid (format: yyyy-MM-dd HH:mm):");
                string validToInput = Console.ReadLine();
                DateTime tempValidTo; 
                while (!DateTime.TryParse(validToInput, out tempValidTo) || tempValidTo < ValidFrom)
                {
                    Console.WriteLine("Ugyldig dato eller gyldig til datoen er tidligere enn gyldig fra datoen. Skriv en gyldig 'Gyldig til' dato (format: yyyy-MM-dd HH:mm):");
                    validToInput = Console.ReadLine();
                }
                // Når gyldig skrives midlertidig verdi til ValidTo
                ValidTo = tempValidTo;

            }
        }

        // Metode som sjekker om e-posten har '@'
        private bool IsValidEmail(string email)
        {
            return email.Contains("@");
        }

        static bool IsValidName(string name)
        {
            string pattern = @"^[a-zA-Z]+$";
            return System.Text.RegularExpressions.Regex.IsMatch(name, pattern);
        }

        static bool IsValidNumber(int number)
        {
            string numberString = number.ToString();
            string pattern = @"^\d{4}$";
            return System.Text.RegularExpressions.Regex.IsMatch(numberString, pattern);
        }
    }
}
